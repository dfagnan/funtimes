package team104;

public abstract class Util {

	public static enum ArchonState {
		FOLLOW, NODE, BATTLE
	}
	
}
